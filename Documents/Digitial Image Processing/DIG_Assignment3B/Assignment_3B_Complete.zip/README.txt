The zipped file contains two sets of code: the 'Assignment_3B_spider' code and the 'Coded_3A_spider'.
The 'Assignment_3B_spider' code is the driver code for this assignment since the 'Coded_3A_spider' is the 
code that was derived from the prvious part of this assignment. 'Assignment_3B_spider' uses the functions from the 'coded 3A'
to avoid retyping the same funtions and to check my work on histogram output per file of an object, plus the test files.

The easy and test folders were modified to have the 'RGB' taken out. This just made it more simple for me to read through the text
file and extract all of the information needed.
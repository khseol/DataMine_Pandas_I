#!/usr/bin/env python
# coding: utf-8

# In[34]:


def getRedFreq(rgb, red):

  #for loop for the red component
    for i in range(len(rgb)):
        if rgb[i][0] in red.keys():
            red[(rgb[i][0])] +=1
        else:
            red.update({rgb[i][0] : 1})

    return red


# In[35]:


def getGreenFreq(rgb, green):

  #for loop for the green component    
    for i in range(len(rgb)):
        if rgb[i][1] in green.keys():
            green[(rgb[i][1])] +=1
        else:
            green.update({rgb[i][1] : 1})
  

    return green


# In[36]:


def getBlueFreq(rgb, blue):

    #for loop for the blue component
    for i in range(len(rgb)):
        if rgb[i][2] in blue.keys():
            blue[(rgb[i][2])] +=1
        else:
            blue.update({rgb[i][2] : 1})
            
    return blue


# In[16]:


#Function for normalizing the frequencies
#This is the last part to do and then output the graph!!!
def normalize(component,normal_component,size):
    #To normalize a component...
    #frequency / total number of pixels ie. dimensions (256*256 and 512*512)
    if type(size) == list:
        total = size[0]*size[1]
        for keys in component.keys():
            #print('this is the current key: ' + str(keys))
            #print('This is the current key vlaue: ' + str(component[keys]))
            normal = (component[keys] / (total)) #TOTAL NUMBER OF PIXELS CHANGES DEPENDING ON THE SIZE AND FILE BEING READ
            normal_component.update({keys:normal})
            #print('current keys normalized value: ' + str(normal))
    else:
        for keys in component.keys():
            #print('this is the current key: ' + str(keys))
            #print('This is the current key vlaue: ' + str(component[keys]))
            normal = (component[keys] / (size)) #TOTAL NUMBER OF PIXELS CHANGES DEPENDING ON THE SIZE AND FILE BEING READ
            normal_component.update({keys:normal})
            #print('current keys normalized value: ' + str(normal))
        
        
    return normal_component


# In[19]:


def getPixels(file):
    string_pixel = ''
    pixel = []
    #THIS VALUE CHANGES DEPENDING ON THE FILE BEING READ
    with open (file) as op:
        for i in op.readlines():
            string_pixel = i
            pixel.append(string_pixel.split())

    #for-loop below changes the string number into int numbers
    for i in range(len(pixel)):
        for j in range(len(pixel[i])):
            pixel[i][j] = int(pixel[i][j])

    #the added coded below is to take the size/total number of pixels of the image for normalizing purposes        
    total_pixels = []
    total_pixels.append(pixel[0][0])
    total_pixels.append(pixel[1][0])

    pixel.pop(0)
    pixel.pop(0)
    
    return pixel, total_pixels


# In[20]:


#######################################################################
#this section will have comments for each picture to avoid picture overlap

import matplotlib.pyplot as plot

def red_hist(red_normal):
    plot.bar(red_normal.keys(), red_normal.values(),5, color = 'r')
    plot.savefig('red_mean_ball.png')
    plot.show()
def green_hist(green_normal):
    plot.bar(green_normal.keys(), green_normal.values(),5, color = 'g')
    plot.savefig('green_mean_ball.png')
    plot.show()
def blue_hist(blue_normal):
    plot.bar(blue_normal.keys(), blue_normal.values(),5, color = 'b')
    plot.savefig('blue_mean_ball.png')
    plot.show()


# In[ ]:





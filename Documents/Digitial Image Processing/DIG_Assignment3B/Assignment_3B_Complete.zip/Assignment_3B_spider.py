import os
from Coded_3A_spider import *
import math as m

#%%
#the function to find the average frequency of each intensities
#formula will go as:
#
# summation of some color intensity frequency i
#_______________________________________________________________________________________ = average
# The number of times the color insntisty has appeared on the set, ie. the txt files, N

#if the set does not have the frequency of the color intensity, the value will be zero, but the N will remain the same regardless as it the total number
#of the sets we have.
#this will be used to obtain the average of a color component from each type of object
def getAverage(n1,n2,n3,n4,n5,n6,n7,n8,n9):
    dummy = {}
    avg = {}
    for i in n1.keys():
        dummy.update({i: n1[i]})
    for i in n2.keys():
        if i in dummy.keys():
            update = n2[i] + dummy[i]
            dummy.update({i:update})
        else:
            dummy.update({i: n2[i]})
    for i in n3.keys():
        if i in dummy.keys():
            update = n3[i] + dummy[i]
            dummy.update({i:update})
        else:
            dummy.update({i: n3[i]})
    for i in n4.keys():
        if i in dummy.keys():
            update = n4[i] + dummy[i]
            dummy.update({i:update})
        else:
            dummy.update({i: n4[i]})
    for i in n5.keys():
        if i in dummy.keys():
            update = n5[i] + dummy[i]
            dummy.update({i:update})
        else:
            dummy.update({i: n5[i]})
    for i in n6.keys():
        if i in dummy.keys():
            update = n6[i] + dummy[i]
            dummy.update({i:update})
        else:
            dummy.update({i: n6[i]})
    for i in n7.keys():
        if i in dummy.keys():
            update = n7[i] + dummy[i]
            dummy.update({i:update})
        else:
            dummy.update({i: n7[i]})
    for i in n8.keys():
        if i in dummy.keys():
            update = n8[i] + dummy[i]
            dummy.update({i:update})
        else:
            dummy.update({i: n8[i]})
    for i in n9.keys():
        if i in dummy.keys():
            update = n9[i] + dummy[i]
            dummy.update({i:update})
        else:
            dummy.update({i: n9[i]})

    for i in dummy.keys():
        avg.update({i: dummy[i]/9})



    return avg

#%%
def rmse(test_file,ballAvg, cyAvg, brAvg):
    rmse_ball = 0 #will be a single value given from the operation
    rmse_cy = 0
    rmse_br = 0
    
    residualBall = {}
    residualCy = {}
    residualBr = {}
    
    for i in test_file.keys():
        if i in ballAvg.keys():
            diff = test_file[i] - ballAvg[i]
            sq_diff = pow(diff,2)
            residualBall.update({i: sq_diff})
    for i in test_file.keys():
        if i in cyAvg.keys():
            diff = test_file[i] - cyAvg[i]
            sq_diff = pow(diff,2)
            residualCy.update({i: sq_diff})
    for i in test_file.keys():
        if i in brAvg.keys():
            diff = test_file[i] - brAvg[i]
            sq_diff = pow(diff,2)
            residualBr.update({i: sq_diff})
    
    n_ball = 0
    s_ball = 0
    
    n_cy = 0
    s_cy = 0
    
    n_br = 0
    s_br = 0
    
    for i in residualBall.keys():
        n_ball+=1
        s_ball+=residualBall[i]
    for i in residualCy.keys():
        n_cy+=1
        s_cy+=residualCy[i]
    for i in residualBr.keys():
        n_br+=1
        s_br+=residualBr[i]
        
    rmse_ball = m.sqrt(s_ball/n_ball)
  
    rmse_cy = m.sqrt(s_cy/n_cy)
   
    rmse_br = m.sqrt(s_br/n_br)
   
    
    return rmse_ball, rmse_cy, rmse_br
            
          
#%%
def getNormals(triplet, total):
    p_r = {}
    p_g = {}
    p_b = {}
    pixel_R = getRedFreq(triplet, p_r)
    pixel_G = getGreenFreq(triplet, p_g)
    pixel_B =getBlueFreq(triplet, p_b)



    return pixel_R, pixel_G, pixel_B

#%%
def shape(redBaRMSE, greenBaRMSE, blueBaRMSE, redCyRMSE, greenCyRMSE, blueCyRMSE, redBrRMSE, greenBrRMSE, blueBrRMSE):
    if ((redBaRMSE < redCyRMSE) and (redBaRMSE < redBrRMSE)):
        if ((greenBaRMSE < greenCyRMSE) and (greenBaRMSE < greenBrRMSE)):
            if((blueBaRMSE < blueCyRMSE) and (blueBaRMSE < blueBrRMSE)):
                return 'ball'
            
    if ((redCyRMSE < redBaRMSE) and (redCyRMSE < redBrRMSE)):
        if ((greenCyRMSE < greenBaRMSE) and (greenCyRMSE < greenBrRMSE)):
            if((blueCyRMSE < blueBaRMSE) and (blueCyRMSE < blueBrRMSE)):
                return 'cylinder'
            
    if ((redBrRMSE < redBaRMSE) and (redBrRMSE < redCyRMSE)):
        if ((greenBrRMSE < greenBaRMSE) and (greenBrRMSE < greenCyRMSE)):
            if((blueBrRMSE < blueBaRMSE) and (blueBrRMSE < blueCyRMSE)):
                return 'brick'
    
#%%: for ball

#below is the test to see if i can access a file from a directory of specific coded name
#BALL
file_path = ".\\easy\\ball\\"
file_list = []
for files in sorted(os.listdir(file_path)):
    file_list.append(files)

test_path1 = file_path + '\\' + file_list[0]
p1,t1 = getPixels(test_path1)
ball_nR1, ball_nG1, ball_nB1 = getNormals(p1,t1)
red_ball = {}
green_ball = {}
blue_ball = {}
red_ball_1 = getRedFreq(p1,red_ball)
green_ball_1 = getGreenFreq(p1,green_ball)
blue_ball_1 = getBlueFreq(p1,blue_ball)
red_ball = {}
green_ball = {}
blue_ball = {}
red_ball_1n = normalize(red_ball_1,red_ball,t1)
green_ball_1n = normalize(green_ball_1,green_ball,t1)
blue_ball_1n = normalize(blue_ball_1,blue_ball,t1)

test_path1 = file_path + '\\' + file_list[1]
p2,t2 = getPixels(test_path1)
ball_nR2, ball_nG2, ball_nB2 = getNormals(p2,t2)
red_ball = {}
green_ball = {}
blue_ball = {}
red_ball_2 = getRedFreq(p2,red_ball)
green_ball_2 = getGreenFreq(p2,green_ball)
blue_ball_2 = getBlueFreq(p2,blue_ball)
red_ball = {}
green_ball = {}
blue_ball = {}
red_ball_2n = normalize(red_ball_2,red_ball,t2)
green_ball_2n = normalize(green_ball_2,green_ball,t2)
blue_ball_2n = normalize(blue_ball_2,blue_ball,t2)

test_path1 = file_path + '\\' + file_list[2]
p3,t3 = getPixels(test_path1)
ball_nR3, ball_nG3, ball_nB3 = getNormals(p3,t3)
red_ball = {}
green_ball = {}
blue_ball = {}
red_ball_3 = getRedFreq(p3,red_ball)
green_ball_3 = getGreenFreq(p3,green_ball)
blue_ball_3 = getBlueFreq(p3,blue_ball)
red_ball = {}
green_ball = {}
blue_ball = {}
red_ball_3n = normalize(red_ball_3,red_ball,t3)
green_ball_3n = normalize(green_ball_3,green_ball,t3)
blue_ball_3n = normalize(blue_ball_3,blue_ball,t3)

test_path1 = file_path + '\\' + file_list[3]
p4,t4 = getPixels(test_path1)
ball_nR4, ball_nG4, ball_nB4 = getNormals(p4,t4)
red_ball = {}
green_ball = {}
blue_ball = {}
red_ball_4 = getRedFreq(p4,red_ball)
green_ball_4 = getGreenFreq(p4,green_ball)
blue_ball_4 = getBlueFreq(p4,blue_ball)
red_ball = {}
green_ball = {}
blue_ball = {}
red_ball_4n = normalize(red_ball_4,red_ball,t4)
green_ball_4n = normalize(green_ball_4,green_ball,t4)
blue_ball_4n = normalize(blue_ball_4,blue_ball,t4)

test_path1 = file_path + '\\' + file_list[4]
p5,t5 = getPixels(test_path1)
ball_nR5, ball_nG5, ball_nB5 = getNormals(p5,t5)
red_ball = {}
green_ball = {}
blue_ball = {}
red_ball_5 = getRedFreq(p5,red_ball)
green_ball_5 = getGreenFreq(p5,green_ball)
blue_ball_5 = getBlueFreq(p5,blue_ball)
red_ball = {}
green_ball = {}
blue_ball = {}
red_ball_5n = normalize(red_ball_5,red_ball,t5)
green_ball_5n = normalize(green_ball_5,green_ball,t5)
blue_ball_5n = normalize(blue_ball_5,blue_ball,t5)

test_path1 = file_path + '\\' + file_list[5]
p6,t6 = getPixels(test_path1)
ball_nR6, ball_nG6, ball_nB6 = getNormals(p6,t6)
red_ball = {}
green_ball = {}
blue_ball = {}
red_ball_6 = getRedFreq(p6,red_ball)
green_ball_6 = getGreenFreq(p6,green_ball)
blue_ball_6 = getBlueFreq(p6,blue_ball)
red_ball = {}
green_ball = {}
blue_ball = {}
red_ball_6n = normalize(red_ball_6,red_ball,t6)
green_ball_6n = normalize(green_ball_6,green_ball,t6)
blue_ball_6n = normalize(blue_ball_6,blue_ball,t6)

test_path1 = file_path + '\\' + file_list[6]
p7,t7 = getPixels(test_path1)
ball_nR7, ball_nG7, ball_nB7 = getNormals(p7,t7)
red_ball = {}
green_ball = {}
blue_ball = {}
red_ball_7 = getRedFreq(p7,red_ball)
green_ball_7 = getGreenFreq(p7,green_ball)
blue_ball_7 = getBlueFreq(p7,blue_ball)
red_ball = {}
green_ball = {}
blue_ball = {}
red_ball_7n = normalize(red_ball_7,red_ball,t7)
green_ball_7n = normalize(green_ball_7,green_ball,t7)
blue_ball_7n = normalize(blue_ball_7,blue_ball,t7)

test_path1 = file_path + '\\' + file_list[7]
p8,t8 = getPixels(test_path1)
ball_nR8, ball_nG8, ball_nB8 = getNormals(p8,t8)
red_ball = {}
green_ball = {}
blue_ball = {}
red_ball_8 = getRedFreq(p8,red_ball)
green_ball_8 = getGreenFreq(p8,green_ball)
blue_ball_8 = getBlueFreq(p8,blue_ball)
red_ball = {}
green_ball = {}
blue_ball = {}
red_ball_8n = normalize(red_ball_8,red_ball,t8)
green_ball_8n = normalize(green_ball_8,green_ball,t8)
blue_ball_8n = normalize(blue_ball_8,blue_ball,t8)

test_path1 = file_path + '\\' + file_list[8]
p9,t9 = getPixels(test_path1)
ball_nR9, ball_nG9, ball_nB9 = getNormals(p9,t9)
red_ball = {}
green_ball = {}
blue_ball = {}
red_ball_9 = getRedFreq(p9,red_ball)
green_ball_9 = getGreenFreq(p9,green_ball)
blue_ball_9 = getBlueFreq(p9,blue_ball)
red_ball = {}
green_ball = {}
blue_ball = {}
red_ball_9n = normalize(red_ball_9,red_ball,t9)
green_ball_9n = normalize(green_ball_9,green_ball,t9)
blue_ball_9n = normalize(blue_ball_9,blue_ball,t9)

#%%
#CYLINDER
file_path2 = ".\\easy\\cylinder\\"
file_list2 = []
for files in sorted(os.listdir(file_path2)):
    file_list2.append(files)

test_path2 = file_path2 + '\\' + file_list2[0]
p1_2,t1_2 = getPixels(test_path2)
cylinder_nR1, cylinder_nG1, cylinder_nB1 = getNormals(p1_2,t1_2)
red_cylinder = {}
green_cylinder = {}
blue_cylinder = {}
red_cylinder_1 = getRedFreq(p1_2,red_cylinder)
green_cylinder_1 = getGreenFreq(p1_2,green_cylinder)
blue_cylinder_1 = getBlueFreq(p1_2,blue_cylinder)
red_cylinder = {}
green_cylinder = {}
blue_cylinder = {}
red_cylinder_1n = normalize(red_cylinder_1,red_cylinder,t1_2)
green_cylinder_1n = normalize(green_cylinder_1,green_cylinder,t1_2)
blue_cylinder_1n = normalize(blue_cylinder_1,blue_cylinder,t1_2)

test_path2 = file_path2 + '\\' + file_list2[1]
p2_2,t2_2 = getPixels(test_path2)
cylinder_nR2, cylinder_nG2, cylinder_nB2 = getNormals(p2_2,t2_2)
red_cylinder = {}
green_cylinder = {}
blue_cylinder = {}
red_cylinder_2 = getRedFreq(p2_2,red_cylinder)
green_cylinder_2 = getGreenFreq(p2_2,green_cylinder)
blue_cylinder_2 = getBlueFreq(p2_2,blue_cylinder)
red_cylinder = {}
green_cylinder = {}
blue_cylinder = {}
red_cylinder_2n = normalize(red_cylinder_2,red_cylinder,t2_2)
green_cylinder_2n = normalize(green_cylinder_2,green_cylinder,t2_2)
blue_cylinder_2n = normalize(blue_cylinder_2,blue_cylinder,t2_2)

test_path2 = file_path2 + '\\' + file_list2[2]
p3_2,t3_2 = getPixels(test_path2)
cylinder_nR3, cylinder_nG3, cylinder_nB3 = getNormals(p3_2,t3_2)
red_cylinder = {}
green_cylinder = {}
blue_cylinder = {}
red_cylinder_3 = getRedFreq(p3_2,red_cylinder)
green_cylinder_3 = getGreenFreq(p3_2,green_cylinder)
blue_cylinder_3 = getBlueFreq(p3_2,blue_cylinder)
red_cylinder = {}
green_cylinder = {}
blue_cylinder = {}
red_cylinder_3n = normalize(red_cylinder_3,red_cylinder,t3_2)
green_cylinder_3n = normalize(green_cylinder_3,green_cylinder,t3_2)
blue_cylinder_3n = normalize(blue_cylinder_3,blue_cylinder,t3_2)

test_path2 = file_path2 + '\\' + file_list2[3]
p4_2,t4_2 = getPixels(test_path2)
cylinder_nR4, cylinder_nG4, cylinder_nB4 = getNormals(p4_2,t4_2)
red_cylinder = {}
green_cylinder = {}
blue_cylinder = {}
red_cylinder_4 = getRedFreq(p4_2,red_cylinder)
green_cylinder_4 = getGreenFreq(p4_2,green_cylinder)
blue_cylinder_4 = getBlueFreq(p4_2,blue_cylinder)
red_cylinder = {}
green_cylinder = {}
blue_cylinder = {}
red_cylinder_4n = normalize(red_cylinder_4,red_cylinder,t4_2)
green_cylinder_4n = normalize(green_cylinder_4,green_cylinder,t4_2)
blue_cylinder_4n = normalize(blue_cylinder_4,blue_cylinder,t4_2)

test_path2 = file_path2 + '\\' + file_list2[4]
p5_2,t5_2 = getPixels(test_path2)
cylinder_nR5, cylinder_nG5, cylinder_nB5 = getNormals(p5_2,t5_2)
red_cylinder = {}
green_cylinder = {}
blue_cylinder = {}
red_cylinder_5 = getRedFreq(p5_2,red_cylinder)
green_cylinder_5 = getGreenFreq(p5_2,green_cylinder)
blue_cylinder_5 = getBlueFreq(p5_2,blue_cylinder)
red_cylinder = {}
green_cylinder = {}
blue_cylinder = {}
red_cylinder_5n = normalize(red_cylinder_5,red_cylinder,t5_2)
green_cylinder_5n = normalize(green_cylinder_5,green_cylinder,t5_2)
blue_cylinder_5n = normalize(blue_cylinder_5,blue_cylinder,t5_2)

test_path2 = file_path2 + '\\' + file_list2[5]
p6_2,t6_2 = getPixels(test_path2)
cylinder_nR6, cylinder_nG6, cylinder_nB6 = getNormals(p6_2,t6_2)
red_cylinder = {}
green_cylinder = {}
blue_cylinder = {}
red_cylinder_6 = getRedFreq(p6_2,red_cylinder)
green_cylinder_6 = getGreenFreq(p6_2,green_cylinder)
blue_cylinder_6 = getBlueFreq(p6_2,blue_cylinder)
red_cylinder = {}
green_cylinder = {}
blue_cylinder = {}
red_cylinder_6n = normalize(red_cylinder_6,red_cylinder,t6_2)
green_cylinder_6n = normalize(green_cylinder_6,green_cylinder,t6_2)
blue_cylinder_6n = normalize(blue_cylinder_6,blue_cylinder,t6_2)

test_path2 = file_path2 + '\\' + file_list2[6]
p7_2,t7_2 = getPixels(test_path2)
cylinder_nR7, cylinder_nG7, cylinder_nB7 = getNormals(p7_2,t7_2)
red_cylinder = {}
green_cylinder = {}
blue_cylinder = {}
red_cylinder_7 = getRedFreq(p7_2,red_cylinder)
green_cylinder_7 = getGreenFreq(p7_2,green_cylinder)
blue_cylinder_7 = getBlueFreq(p7_2,blue_cylinder)
red_cylinder = {}
green_cylinder = {}
blue_cylinder = {}
red_cylinder_7n = normalize(red_cylinder_7,red_cylinder,t7_2)
green_cylinder_7n = normalize(green_cylinder_7,green_cylinder,t7_2)
blue_cylinder_7n = normalize(blue_cylinder_7,blue_cylinder,t7_2)

test_path2 = file_path2 + '\\' + file_list2[7]
p8_2,t8_2 = getPixels(test_path2)
cylinder_nR8, cylinder_nG8, cylinder_nB8 = getNormals(p8_2,t8_2)
red_cylinder = {}
green_cylinder = {}
blue_cylinder = {}
red_cylinder_8 = getRedFreq(p8_2,red_cylinder)
green_cylinder_8 = getGreenFreq(p8_2,green_cylinder)
blue_cylinder_8 = getBlueFreq(p8_2,blue_cylinder)
red_cylinder = {}
green_cylinder = {}
blue_cylinder = {}
red_cylinder_8n = normalize(red_cylinder_8,red_cylinder,t8_2)
green_cylinder_8n = normalize(green_cylinder_8,green_cylinder,t8_2)
blue_cylinder_8n = normalize(blue_cylinder_8,blue_cylinder,t8_2)

test_path2 = file_path2 + '\\' + file_list2[8]
p9_2,t9_2 = getPixels(test_path2)
cylinder_nR9, cylinder_nG9, cylinder_nB9 = getNormals(p8_2,t9_2)
red_cylinder = {}
green_cylinder = {}
blue_cylinder = {}
red_cylinder_9 = getRedFreq(p9_2,red_cylinder)
green_cylinder_9 = getGreenFreq(p9_2,green_cylinder)
blue_cylinder_9 = getBlueFreq(p9_2,blue_cylinder)
red_cylinder = {}
green_cylinder = {}
blue_cylinder = {}
red_cylinder_9n = normalize(red_cylinder_9,red_cylinder,t9_2)
green_cylinder_9n = normalize(green_cylinder_9,green_cylinder,t9_2)
blue_cylinder_9n = normalize(blue_cylinder_9,blue_cylinder,t9_2)

#%%
#BRICK
file_path3 = ".\\easy\\brick\\"
file_list3 = []
for files in sorted(os.listdir(file_path3)):
    file_list3.append(files)

test_path3 = file_path3 + '\\' + file_list3[0]
p1_3,t1_3 = getPixels(test_path3)
brick_nR1, brick_nG1, brick_nB1 = getNormals(p1_3,t1_3)
red_brick = {}
green_brick = {}
blue_brick = {}
red_brick_1 = getRedFreq(p1_3,red_brick)
green_brick_1 = getGreenFreq(p1_3,green_brick)
blue_brick_1 = getBlueFreq(p1_3,blue_brick)
red_brick = {}
green_brick = {}
blue_brick = {}
red_brick_1n = normalize(red_brick_1,red_brick,t1_3)
green_brick_1n = normalize(green_brick_1,green_brick,t1_3)
blue_brick_1n = normalize(blue_brick_1,blue_brick,t1_3)

test_path3 = file_path3 + '\\' + file_list3[1]
p2_3,t2_3 = getPixels(test_path3)
brick_nR2, brick_nG2, brick_nB2 = getNormals(p2_3,t2_3)
red_brick = {}
green_brick = {}
blue_brick = {}
red_brick_2 = getRedFreq(p2_3,red_brick)
green_brick_2 = getGreenFreq(p2_3,green_brick)
blue_brick_2 = getBlueFreq(p2_3,blue_brick)
red_brick = {}
green_brick = {}
blue_brick = {}
red_brick_2n = normalize(red_brick_2,red_brick,t2_3)
green_brick_2n = normalize(green_brick_2,green_brick,t2_3)
blue_brick_2n = normalize(blue_brick_2,blue_brick,t2_3)

test_path3 = file_path3 + '\\' + file_list3[2]
p3_3,t3_3 = getPixels(test_path3)
brick_nR3, brick_nG3, brick_nB3 = getNormals(p3_3,t3_3)
red_brick = {}
green_brick = {}
blue_brick = {}
red_brick_3 = getRedFreq(p3_3,red_brick)
green_brick_3 = getGreenFreq(p3_3,green_brick)
blue_brick_3 = getBlueFreq(p3_3,blue_brick)
red_brick = {}
green_brick = {}
blue_brick = {}
red_brick_3n = normalize(red_brick_3,red_brick,t3_3)
green_brick_3n = normalize(green_brick_3,green_brick,t3_3)
blue_brick_3n = normalize(blue_brick_3,blue_brick,t3_3)

test_path3 = file_path3 + '\\' + file_list3[3]
p4_3,t4_3 = getPixels(test_path3)
brick_nR4, brick_nG4, brick_nB4 = getNormals(p4_3,t4_3)
red_brick = {}
green_brick = {}
blue_brick = {}
red_brick_4 = getRedFreq(p4_3,red_brick)
green_brick_4 = getGreenFreq(p4_3,green_brick)
blue_brick_4 = getBlueFreq(p4_3,blue_brick)
red_brick = {}
green_brick = {}
blue_brick = {}
red_brick_4n = normalize(red_brick_4,red_brick,t4_3)
green_brick_4n = normalize(green_brick_4,green_brick,t4_3)
blue_brick_4n = normalize(blue_brick_4,blue_brick,t4_3)

test_path3 = file_path3 + '\\' + file_list3[4]
p5_3,t5_3 = getPixels(test_path3)
brick_nR5, brick_nG5, brick_nB5 = getNormals(p5_3,t5_3)
red_brick = {}
green_brick = {}
blue_brick = {}
red_brick_5 = getRedFreq(p5_3,red_brick)
green_brick_5 = getGreenFreq(p5_3,green_brick)
blue_brick_5 = getBlueFreq(p5_3,blue_brick)
red_brick = {}
green_brick = {}
blue_brick = {}
red_brick_5n = normalize(red_brick_5,red_brick,t5_3)
green_brick_5n = normalize(green_brick_5,green_brick,t5_3)
blue_brick_5n = normalize(blue_brick_5,blue_brick,t5_3)

test_path3 = file_path3 + '\\' + file_list3[5]
p6_3,t6_3 = getPixels(test_path3)
brick_nR6, brick_nG6, brick_nB6 = getNormals(p6_3,t6_3)
red_brick = {}
green_brick = {}
blue_brick = {}
red_brick_6 = getRedFreq(p6_3,red_brick)
green_brick_6 = getGreenFreq(p6_3,green_brick)
blue_brick_6 = getBlueFreq(p6_3,blue_brick)
red_brick = {}
green_brick = {}
blue_brick = {}
red_brick_6n = normalize(red_brick_6,red_brick,t6_3)
green_brick_6n = normalize(green_brick_6,green_brick,t6_3)
blue_brick_6n = normalize(blue_brick_6,blue_brick,t6_3)

test_path3 = file_path3 + '\\' + file_list3[6]
p7_3,t7_3 = getPixels(test_path3)
brick_nR7, brick_nG7, brick_nB7 = getNormals(p7_3,t7_3)
red_brick = {}
green_brick = {}
blue_brick = {}
red_brick_7 = getRedFreq(p7_3,red_brick)
green_brick_7 = getGreenFreq(p7_3,green_brick)
blue_brick_7 = getBlueFreq(p7_3,blue_brick)
red_brick = {}
green_brick = {}
blue_brick = {}
red_brick_7n = normalize(red_brick_7,red_brick,t7_3)
green_brick_7n = normalize(green_brick_7,green_brick,t7_3)
blue_brick_7n = normalize(blue_brick_7,blue_brick,t7_3)

test_path3 = file_path3 + '\\' + file_list3[7]
p8_3,t8_3 = getPixels(test_path3)
brick_nR8, brick_nG8, brick_nB8 = getNormals(p8_3,t8_3)
red_brick = {}
green_brick = {}
blue_brick = {}
red_brick_8 = getRedFreq(p8_3,red_brick)
green_brick_8 = getGreenFreq(p8_3,green_brick)
blue_brick_8 = getBlueFreq(p8_3,blue_brick)
red_brick = {}
green_brick = {}
blue_brick = {}
red_brick_8n = normalize(red_brick_8,red_brick,t8_3)
green_brick_8n = normalize(green_brick_8,green_brick,t8_3)
blue_brick_8n = normalize(blue_brick_8,blue_brick,t8_3)

test_path3 = file_path3 + '\\' + file_list3[8]
p9_3,t9_3 = getPixels(test_path3)
brick_nR9, brick_nG9, brick_nB9 = getNormals(p8_3,t9_3)
red_brick = {}
green_brick = {}
blue_brick = {}
red_brick_9 = getRedFreq(p9_3,red_brick)
green_brick_9 = getGreenFreq(p9_3,green_brick)
blue_brick_9 = getBlueFreq(p9_3,blue_brick)
red_brick = {}
green_brick = {}
blue_brick = {}
red_brick_9n = normalize(red_brick_9,red_brick,t9_3)
green_brick_9n = normalize(green_brick_9,green_brick,t9_3)
blue_brick_9n = normalize(blue_brick_9,blue_brick,t9_3)


bRedAvg = (getAverage(red_ball_1n, red_ball_2n, red_ball_3n, red_ball_4n, red_ball_5n,red_ball_6n, red_ball_7n, red_ball_8n, red_ball_9n))
bGreenAvg = (getAverage(green_ball_1n, green_ball_2n, green_ball_3n, green_ball_4n, green_ball_5n,green_ball_6n, green_ball_7n, green_ball_8n, green_ball_9n))
bBlueAvg = (getAverage(blue_ball_1n, blue_ball_2n, blue_ball_3n, blue_ball_4n, blue_ball_5n,blue_ball_6n, blue_ball_7n, blue_ball_8n, blue_ball_9n))


cyRedAvg = (getAverage(red_cylinder_1n, red_cylinder_2n, red_cylinder_3n, red_cylinder_4n, red_cylinder_5n,red_cylinder_6n, red_cylinder_7n, red_cylinder_8n, red_cylinder_9n))
cyGreenAvg = (getAverage(green_cylinder_1n, green_cylinder_2n, green_cylinder_3n, green_cylinder_4n, green_cylinder_5n,green_cylinder_6n, green_cylinder_7n, green_cylinder_8n, green_cylinder_9n))
cyBlueAvg = (getAverage(blue_cylinder_1n, blue_cylinder_2n, blue_cylinder_3n, blue_cylinder_4n, blue_cylinder_5n,blue_cylinder_6n, blue_cylinder_7n, blue_cylinder_8n, blue_cylinder_9n))


brRedAvg = (getAverage(red_brick_1n, red_brick_2n, red_brick_3n, red_brick_4n, red_brick_5n,red_brick_6n, red_brick_7n, red_brick_8n, red_brick_9n))
brGreenAvg = (getAverage(green_brick_1n, green_brick_2n, green_brick_3n, green_brick_4n, green_brick_5n,green_brick_6n, green_brick_7n, green_brick_8n, green_brick_9n))
brBlueAvg = (getAverage(blue_brick_1n, blue_brick_2n, blue_brick_3n, blue_brick_4n, blue_brick_5n,blue_brick_6n, blue_brick_7n, blue_brick_8n, blue_brick_9n))

#%%
#error testing
output = open('answers.txt','w')

test_path = ".\\test"
test_list = []
for files in sorted(os.listdir(test_path)):
    test_list.append(files)

testing1 = test_path + '\\' + test_list[0]
testP1,testT1 = getPixels(testing1)
redTest = {}
greenTest = {}
blueTest = {}
redTest1 = getRedFreq(testP1,redTest)
greenTest1 = getGreenFreq(testP1,greenTest)
blueTest1 = getBlueFreq(testP1, blueTest)
redTest = {}
greenTest = {}
blueTest = {}
redTest1_n = normalize(redTest1, redTest,testT1)
greenTest1_n = normalize(greenTest1, greenTest,testT1)
blueTest1_n = normalize(blueTest1, blueTest, testT1)

redRMSEba, redRMSEcy, redRMSEbr = rmse(redTest1_n, bRedAvg, cyRedAvg,brRedAvg)
greenRMSEba, greenRMSEcy, greenRMSEbr = rmse(greenTest1_n, bGreenAvg, cyGreenAvg,brGreenAvg)
blueRMSEba, blueRMSEcy, blueRMSEbr = rmse(blueTest1_n, bBlueAvg, cyBlueAvg,brBlueAvg)
file_pic = shape(redRMSEba, greenRMSEba, blueRMSEba, redRMSEcy, greenRMSEcy,blueRMSEcy, redRMSEbr, greenRMSEbr, blueRMSEbr)
output_str = test_list[0] + '--' + file_pic + '\n'
output.write(output_str)


testing2 = test_path + '\\' + test_list[1]
testP1,testT1 = getPixels(testing2)
redTest = {}
greenTest = {}
blueTest = {}
redTest1 = getRedFreq(testP1,redTest)
greenTest1 = getGreenFreq(testP1,greenTest)
blueTest1 = getBlueFreq(testP1, blueTest)
redTest = {}
greenTest = {}
blueTest = {}
redTest1_n = normalize(redTest1, redTest,testT1)
greenTest1_n = normalize(greenTest1, greenTest,testT1)
blueTest1_n = normalize(blueTest1, blueTest, testT1)

redRMSEba, redRMSEcy, redRMSEbr = rmse(redTest1_n, bRedAvg, cyRedAvg,brRedAvg)
greenRMSEba, greenRMSEcy, greenRMSEbr = rmse(greenTest1_n, bGreenAvg, cyGreenAvg,brGreenAvg)
blueRMSEba, blueRMSEcy, blueRMSEbr = rmse(blueTest1_n, bBlueAvg, cyBlueAvg,brBlueAvg)
file_pic = shape(redRMSEba, greenRMSEba, blueRMSEba, redRMSEcy, greenRMSEcy,blueRMSEcy, redRMSEbr, greenRMSEbr, blueRMSEbr)
output_str = test_list[1] + '--' + file_pic + '\n'
output.write(output_str)

testing3 = test_path + '\\' + test_list[2]
testP1,testT1 = getPixels(testing3)
redTest = {}
greenTest = {}
blueTest = {}
redTest1 = getRedFreq(testP1,redTest)
greenTest1 = getGreenFreq(testP1,greenTest)
blueTest1 = getBlueFreq(testP1, blueTest)
redTest = {}
greenTest = {}
blueTest = {}
redTest1_n = normalize(redTest1, redTest,testT1)
greenTest1_n = normalize(greenTest1, greenTest,testT1)
blueTest1_n = normalize(blueTest1, blueTest, testT1)

redRMSEba, redRMSEcy, redRMSEbr = rmse(redTest1_n, bRedAvg, cyRedAvg,brRedAvg)
greenRMSEba, greenRMSEcy, greenRMSEbr = rmse(greenTest1_n, bGreenAvg, cyGreenAvg,brGreenAvg)
blueRMSEba, blueRMSEcy, blueRMSEbr = rmse(blueTest1_n, bBlueAvg, cyBlueAvg,brBlueAvg)
file_pic = shape(redRMSEba, greenRMSEba, blueRMSEba, redRMSEcy, greenRMSEcy,blueRMSEcy, redRMSEbr, greenRMSEbr, blueRMSEbr)
output_str = test_list[2] + '--' + file_pic + '\n'
output.write(output_str)

testing4 = test_path + '\\' + test_list[3]
testP1,testT1 = getPixels(testing4)
redTest = {}
greenTest = {}
blueTest = {}
redTest1 = getRedFreq(testP1,redTest)
greenTest1 = getGreenFreq(testP1,greenTest)
blueTest1 = getBlueFreq(testP1, blueTest)
redTest = {}
greenTest = {}
blueTest = {}
redTest1_n = normalize(redTest1, redTest,testT1)
greenTest1_n = normalize(greenTest1, greenTest,testT1)
blueTest1_n = normalize(blueTest1, blueTest, testT1)

redRMSEba, redRMSEcy, redRMSEbr = rmse(redTest1_n, bRedAvg, cyRedAvg,brRedAvg)
greenRMSEba, greenRMSEcy, greenRMSEbr = rmse(greenTest1_n, bGreenAvg, cyGreenAvg,brGreenAvg)
blueRMSEba, blueRMSEcy, blueRMSEbr = rmse(blueTest1_n, bBlueAvg, cyBlueAvg,brBlueAvg)
file_pic = shape(redRMSEba, greenRMSEba, blueRMSEba, redRMSEcy, greenRMSEcy,blueRMSEcy, redRMSEbr, greenRMSEbr, blueRMSEbr)
output_str = test_list[3] + '--' + file_pic + '\n'
output.write(output_str)

testing5 = test_path + '\\' + test_list[4]
testP1,testT1 = getPixels(testing5)
redTest = {}
greenTest = {}
blueTest = {}
redTest1 = getRedFreq(testP1,redTest)
greenTest1 = getGreenFreq(testP1,greenTest)
blueTest1 = getBlueFreq(testP1, blueTest)
redTest = {}
greenTest = {}
blueTest = {}
redTest1_n = normalize(redTest1, redTest,testT1)
greenTest1_n = normalize(greenTest1, greenTest,testT1)
blueTest1_n = normalize(blueTest1, blueTest, testT1)

redRMSEba, redRMSEcy, redRMSEbr = rmse(redTest1_n, bRedAvg, cyRedAvg,brRedAvg)
greenRMSEba, greenRMSEcy, greenRMSEbr = rmse(greenTest1_n, bGreenAvg, cyGreenAvg,brGreenAvg)
blueRMSEba, blueRMSEcy, blueRMSEbr = rmse(blueTest1_n, bBlueAvg, cyBlueAvg,brBlueAvg)
file_pic = shape(redRMSEba, greenRMSEba, blueRMSEba, redRMSEcy, greenRMSEcy,blueRMSEcy, redRMSEbr, greenRMSEbr, blueRMSEbr)
output_str = test_list[4] + '--' + file_pic + '\n'
output.write(output_str)


testing6 = test_path + '\\' + test_list[5]
testP1,testT1 = getPixels(testing6)
redTest = {}
greenTest = {}
blueTest = {}
redTest1 = getRedFreq(testP1,redTest)
greenTest1 = getGreenFreq(testP1,greenTest)
blueTest1 = getBlueFreq(testP1, blueTest)
redTest = {}
greenTest = {}
blueTest = {}
redTest1_n = normalize(redTest1, redTest,testT1)
greenTest1_n = normalize(greenTest1, greenTest,testT1)
blueTest1_n = normalize(blueTest1, blueTest, testT1)

redRMSEba, redRMSEcy, redRMSEbr = rmse(redTest1_n, bRedAvg, cyRedAvg,brRedAvg)
greenRMSEba, greenRMSEcy, greenRMSEbr = rmse(greenTest1_n, bGreenAvg, cyGreenAvg,brGreenAvg)
blueRMSEba, blueRMSEcy, blueRMSEbr = rmse(blueTest1_n, bBlueAvg, cyBlueAvg,brBlueAvg)
file_pic = shape(redRMSEba, greenRMSEba, blueRMSEba, redRMSEcy, greenRMSEcy,blueRMSEcy, redRMSEbr, greenRMSEbr, blueRMSEbr)
output_str = test_list[5] + '--' + file_pic + '\n'
output.write(output_str)

testing7 = test_path + '\\' + test_list[6]
testP1,testT1 = getPixels(testing7)
redTest = {}
greenTest = {}
blueTest = {}
redTest1 = getRedFreq(testP1,redTest)
greenTest1 = getGreenFreq(testP1,greenTest)
blueTest1 = getBlueFreq(testP1, blueTest)
redTest = {}
greenTest = {}
blueTest = {}
redTest1_n = normalize(redTest1, redTest,testT1)
greenTest1_n = normalize(greenTest1, greenTest,testT1)
blueTest1_n = normalize(blueTest1, blueTest, testT1)

redRMSEba, redRMSEcy, redRMSEbr = rmse(redTest1_n, bRedAvg, cyRedAvg,brRedAvg)
greenRMSEba, greenRMSEcy, greenRMSEbr = rmse(greenTest1_n, bGreenAvg, cyGreenAvg,brGreenAvg)
blueRMSEba, blueRMSEcy, blueRMSEbr = rmse(blueTest1_n, bBlueAvg, cyBlueAvg,brBlueAvg)
file_pic = shape(redRMSEba, greenRMSEba, blueRMSEba, redRMSEcy, greenRMSEcy,blueRMSEcy, redRMSEbr, greenRMSEbr, blueRMSEbr)
output_str = test_list[6] + '--' + file_pic + '\n'
output.write(output_str)

output.close()